package com.novaos.launcher

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Build
import android.os.Process
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

private val Bg = Color(0xFF080D18)
private val Panel = Color(0xFF111C30)
private val Blue = Color(0xFF58A6FF)

data class GameApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        setContent { NovaHome() }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Android/Compose focus navigation handles controller D-pad and keyboard navigation.
        return super.onKeyDown(keyCode, event)
    }
}

@Composable
fun NovaHome() {
    val context = LocalContext.current
    val pm = context.packageManager
    var apps by remember { mutableStateOf(loadApps(pm)) }
    var selectedTab by remember { mutableStateOf("GAMES") }
    var status by remember { mutableStateOf("Ready to play") }
    var memoryText by remember { mutableStateOf("--") }
    var tempText by remember { mutableStateOf("Not available") }

    LaunchedEffect(Unit) {
        while (true) {
            val am = context.getSystemService(Activity.ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            memoryText = "${info.availMem / (1024 * 1024)} MB available"
            if (Build.VERSION.SDK_INT >= 29) {
                val pmgr = context.getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
                tempText = "Thermal status ${pmgr.currentThermalStatus}/6"
            }
            delay(3000)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Blue,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Row(
            Modifier.fillMaxSize().background(Bg).padding(22.dp),
            horizontalArrangement = Arrangement.spacedBy(22.dp)
        ) {
            Column(Modifier.width(205.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("NOVA", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black)
                    Text("GAMING SYSTEM", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(26.dp))
                    listOf("GAMES", "BOOSTER", "SYSTEM").forEach { tab ->
                        Surface(
                            color = if (selectedTab == tab) Color(0xFF1B3557) else Panel,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().clickable { selectedTab = tab }
                        ) {
                            Text(tab, Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                                color = if (selectedTab == tab) Blue else Color.LightGray,
                                fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("NOVA OS  •  v1.1", color = Color(0xFF71829D), fontSize = 11.sp)
                    OutlinedButton(
                        onClick = { (context as? Activity)?.finishAffinity() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF8FC5FF))
                    ) {
                        Icon(Icons.Default.ExitToApp, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("EXIT APP", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(
                            when (selectedTab) {
                                "BOOSTER" -> "PERFORMANCE CENTER"
                                "SYSTEM" -> "SYSTEM STATUS"
                                else -> "YOUR GAME LIBRARY"
                            },
                            color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold
                        )
                        Text("YOUR PHONE. YOUR CONSOLE.", color = Color(0xFF8EA4C4), fontSize = 11.sp)
                    }
                    Text("●  ONLINE", color = Color(0xFF65D69A), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(18.dp))

                when (selectedTab) {
                    "GAMES" -> {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Gamepad, contentDescription = null, tint = Blue)
                            Text("${apps.size} INSTALLED APPS", color = Color(0xFF9FB2CE), fontSize = 12.sp)
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { apps = loadApps(pm); status = "Library refreshed" }) {
                                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Blue)
                            }
                        }
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 112.dp),
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(top = 10.dp, bottom = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(apps, key = { it.packageName }) { app ->
                                Column(
                                    Modifier.clip(RoundedCornerShape(16.dp))
                                        .background(Panel).clickable {
                                            val launch = pm.getLaunchIntentForPackage(app.packageName)
                                            if (launch != null) context.startActivity(launch)
                                        }.padding(12.dp).fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    androidx.compose.ui.viewinterop.AndroidView(
                                        factory = { ctx -> android.widget.ImageView(ctx).apply {
                                            setImageDrawable(app.icon)
                                            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                                        } },
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Text(app.label, color = Color.White, fontSize = 12.sp, maxLines = 2, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                    "BOOSTER" -> {
                        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            Text("BOOSTER READY", color = Blue, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text("Available memory: $memoryText", color = Color.White)
                            Text("Device thermal: $tempText", color = Color.White)
                            Text("Android manages app processes and CPU/GPU performance. NOVA does not force-stop other apps or promise extra FPS.", color = Color(0xFF9FB2CE), fontSize = 12.sp)
                            Button(onClick = { status = "Memory and thermal status refreshed" }) {
                                Icon(Icons.Default.Bolt, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("OPTIMIZE CHECK")
                            }
                            Text(status, color = Color(0xFF65D69A), fontSize = 12.sp)
                        }
                    }
                    else -> {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Memory: $memoryText", color = Color.White)
                            Text("Thermal: $tempText", color = Color.White)
                            Text("Landscape mode: ON", color = Color.White)
                            Text("Controller / keyboard / mouse: Android input support", color = Color.White)
                            Text("Open NOVA OS from its app icon. Your normal phone Home screen stays unchanged.", color = Color(0xFF9FB2CE), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

private fun loadApps(pm: PackageManager): List<GameApp> {
    val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .mapNotNull { ri ->
            val name = ri.loadLabel(pm)?.toString() ?: return@mapNotNull null
            val pkg = ri.activityInfo.packageName
            if (pkg == "com.novaos.launcher") null else GameApp(name, pkg, ri.loadIcon(pm))
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase(Locale.getDefault()) }
}
